API_KEY = ""
API_ENDPOINT = 'https://gateway-8eur6cwg.ue.gateway.dev'
