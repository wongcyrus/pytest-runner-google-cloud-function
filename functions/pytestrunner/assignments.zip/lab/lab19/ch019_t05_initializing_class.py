class Car(object):

    def __init__(self):
        self.condition = "new"


my_car = Car()
print(my_car.condition)
