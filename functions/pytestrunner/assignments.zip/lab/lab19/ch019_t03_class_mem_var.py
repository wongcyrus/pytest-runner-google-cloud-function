class Car(object):
    def __init__(self):
        pass


my_car = Car()
