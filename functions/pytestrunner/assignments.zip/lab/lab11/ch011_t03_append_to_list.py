n = [1, 3, 5]
# Append the number 4 here

print(n)
