m = [1, 2, 3]
n = [4, 5, 6]

# Add your code here!


# print(join_lists(m, n))
# You want this to print [1, 2, 3, 4, 5, 6]
