number = 5


def my_function(x: int) -> int:
    return x + 3


print(my_function(number))
