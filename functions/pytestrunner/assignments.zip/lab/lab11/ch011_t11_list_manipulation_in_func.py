n = [3, 5, 7]
# Add your function here


# print(list_extender(n))
