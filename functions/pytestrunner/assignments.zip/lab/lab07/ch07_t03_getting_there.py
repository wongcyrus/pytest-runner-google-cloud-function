def hotel_cost(nights: int) -> int:
    return 140 * nights
