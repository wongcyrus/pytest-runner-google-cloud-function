# Ask Python to print sqrt(25) on line 3.

print(sqrt(25))
