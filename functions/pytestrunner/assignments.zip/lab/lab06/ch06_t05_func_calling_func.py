def one_good_turn(n: int):
    return n + 1


def deserves_another(n: int):
    return n + 2
