# Set minimum to the min value of any set of numbers on line 3!

minimum = None

print(minimum)
