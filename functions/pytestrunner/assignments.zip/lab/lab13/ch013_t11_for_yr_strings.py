thing = "spam!"

for c in thing:
    print(c)

word = "eggs!"

# Your code here!
