count = 0

while True:
    print(count)
    count += 1
    if count >= 10:
        break
