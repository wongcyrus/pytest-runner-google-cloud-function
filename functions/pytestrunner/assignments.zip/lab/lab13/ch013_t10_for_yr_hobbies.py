hobbies = []

# Add your code below!
