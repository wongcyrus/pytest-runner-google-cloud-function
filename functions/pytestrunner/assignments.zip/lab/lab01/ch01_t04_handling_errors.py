# print("How do you make a hot dog stand?')
# print(You take away its chair!)
