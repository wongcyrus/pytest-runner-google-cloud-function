city_name = "St. Potatosburg"

city_pop = 340000
