"""Assign the string "Ping!" to
the variable the_machine_goes on
line 5, then print it out on line 6!"""
