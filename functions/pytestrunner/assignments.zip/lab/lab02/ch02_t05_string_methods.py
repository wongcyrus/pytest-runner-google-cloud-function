print
