parrot = "Norwegian Blue"

print()
