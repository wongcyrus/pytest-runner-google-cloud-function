class Animal(object):
    """Makes cute animals."""
    is_alive = True

    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age
    # Add your method here!
