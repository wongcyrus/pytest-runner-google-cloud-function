# WARNING: THIS WILL NOT WORK

words = 'the cat sat on the mat'.split()
counts = {}

for word in words:
    counts[word] += 1

print(counts)
