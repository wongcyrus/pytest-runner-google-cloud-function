numbers = [45, 76, -23, 90, 15]

total = 0

for number in numbers:
    total += number

print(total)
