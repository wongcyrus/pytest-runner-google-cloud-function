message = input('Message? ')
print(message)
