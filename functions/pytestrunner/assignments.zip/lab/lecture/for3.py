numbers = [4, 7, -2, 9, 1]
squares = []

for number in numbers:
    squares.append(number ** 2)

print(squares)
