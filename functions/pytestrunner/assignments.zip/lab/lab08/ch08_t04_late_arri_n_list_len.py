suitcase = []
suitcase.append("sunglasses")

# Your code here!


list_length = 1  # Set this to the length of suitcase

print("There are %d items in the suitcase." % list_length)
print(suitcase)
