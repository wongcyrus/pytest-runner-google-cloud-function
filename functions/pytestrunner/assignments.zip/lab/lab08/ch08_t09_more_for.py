start_list = [5, 3, 1, 2, 4]
square_list = []

# Your code here!


print(square_list)
