API_KEY = ""
API_ENDPOINT = 'https://api-grading-engine-assignment.azure-api.net'
