n = [1, 3, 5]
# Do your multiplication here

print(n)
