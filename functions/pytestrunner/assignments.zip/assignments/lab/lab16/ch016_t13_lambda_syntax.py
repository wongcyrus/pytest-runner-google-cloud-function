languages = ["HTML", "JavaScript", "Python", "Ruby"]

# Add arguments to the filter()
print(list(filter([], None)))
