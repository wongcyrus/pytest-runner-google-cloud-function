my_dict = {
    "Name": "Peter",
    "Age": 18,
    "BDFL": True
}
print(my_dict.items())
