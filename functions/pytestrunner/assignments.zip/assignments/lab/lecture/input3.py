text = input('N? ')
number = int(text)
print(number + 1)
