print('''coffee
café
caffè
Kaffee''')
