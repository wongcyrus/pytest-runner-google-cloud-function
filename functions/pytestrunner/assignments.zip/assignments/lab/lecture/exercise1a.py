print('Goodbye, world!')
