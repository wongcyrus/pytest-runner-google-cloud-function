# Establish a dictionary which translates 'cat', 'dog', and 'mouse' into French.
en_to_fr = {'cat': 'chien', 'dog': 'chien', 'mouse': 'souris'}

# Add 'snake' to it.
en_to_fr['snake'] = 'serpent'

# Print the dictionary
print(en_to_fr)
