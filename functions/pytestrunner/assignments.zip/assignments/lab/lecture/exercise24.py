ages = [('Joe', 9), ('Samantha', 45), ('Methuselah', 969)]

# for (name, age) in ages:
#     print('XXXX'.format(XXXX))
