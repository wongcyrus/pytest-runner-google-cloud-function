shift_right = 0b1100
shift_left = 0b1

# Your code here!


print(bin(shift_right))
print(bin(shift_left))
