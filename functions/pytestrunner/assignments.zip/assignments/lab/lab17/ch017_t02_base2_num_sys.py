print(0b1, end=" ")  # 1
print(0b10, end=" ")  # 2
print(0b11, end=" ")  # 3
print(0b100, end=" ")  # 4
print(0b101, end=" ")  # 5
print(0b110, end=" ")  # 6
print(0b111, end=" ")  # 7
print("******")
print(0b1 + 0b11)
print(0b11 * 0b11)
