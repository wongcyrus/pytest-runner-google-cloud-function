print('Welcome to the Pig Latin Translator!')

# Start coding here!
