# Define your spam function starting on line 5. You
# can leave the code on line 10 alone for now--we'll
# explain it soon!


# Define the spam function above this line.
spam()
