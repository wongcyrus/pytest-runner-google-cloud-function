board = []
for i in range(5):
    board.append(['O'] * 5)

print(board)
