# Assign True or False as appropriate on the lines below!

# Set this to True if 17 < 328 or to False if it is not.
bool_one = True  # We did this one for you!

# Set this to True if 100 == (2 * 50) or to False otherwise.
bool_two = None

# Set this to True if 19 <= 19 or to False if it is not.
bool_three = None

# Set this to True if -22 >= -18 or to False if it is not.
bool_four = None

# Set this to True if 99 != (98 + 1) or to False otherwise.
bool_five = None
