menu = {}  # Empty dictionary
menu['Chicken Alfredo'] = 14.50  # Adding new key-value pair
print(menu['Chicken Alfredo'])

# Your code here: Add some dish-price pairs to menu!


print("There are " + str(len(menu)) + " items on the menu.")
print(menu)
