animals = ["aardvark", "badger", "duck", "emu", "fennec fox"]
duck_index = None  # Use index() to find "duck"

# Your code here!


print(animals)  # Observe what prints after the insert operation
